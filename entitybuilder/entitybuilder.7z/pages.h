#pragma once
#include <SFGUI/Widgets.hpp>
#include <unordered_map>
#include "db.h"

class Builder;
class Page
{
public:
	using Ptr = std::unique_ptr<Page>;
	virtual ~Page() = default;
	static void set_builder(Builder* builder) { m_builder = builder; }
	virtual sfg::Widget::Ptr get_page() = 0;
	virtual bool validate() = 0;
	virtual int insert_into_database(db::db_connection_ptr& db) = 0;
protected:
	static Builder * m_builder;
};

class Entity_page : public Page
{
	enum class Button { Shared, Projectile };
public:
	using Ptr = std::unique_ptr<Entity_page>;
	static Ptr create() { return std::make_unique<Entity_page>(); }
	Entity_page();
	sfg::Widget::Ptr get_page() override { return m_page; }
	bool validate() override;
	int insert_into_database(db::db_connection_ptr& db) override { return 0; }
private:
	void handle_button(Entity_page::Button button);
	
	sfg::Widget::Ptr m_page;
	sfg::Entry::Ptr m_name_entry;
	std::unordered_map<Button, sfg::CheckButton::Ptr> m_buttons;
};

enum class Value_type { String, Integer, Float };

class Shared_page : public Page
{
public:
	
	Shared_page();
	using Ptr = std::unique_ptr<Shared_page>;
	static Ptr create() { return std::make_unique <Shared_page>(); }
	sfg::Widget::Ptr get_page() override { return m_page; }
	bool validate() override;
	int insert_into_database(db::db_connection_ptr& db) override;
private:
	//void validate_text(Value_type type, sfg::Entry::Ptr entry);

	sfg::Widget::Ptr m_page;
	sfg::Entry::Ptr m_name_entry;
	sfg::Entry::Ptr m_description_entry;
	sfg::Entry::Ptr m_weight_entry;
	sfg::Entry::Ptr m_price_entry;
	sfg::Label::Ptr m_error_msg;
	db::prepared_statement_ptr m_insert_stmt = nullptr;
	db::prepared_statement_ptr m_max_index = nullptr;
};

class Projectile_page : public Page
{
public:
	Projectile_page();
	using Ptr = std::unique_ptr < Projectile_page>;
	static Ptr create() { return std::make_unique<Projectile_page>(); }
	sfg::Widget::Ptr get_page() override { return m_page; }
	bool validate() override;
	int insert_into_database(db::db_connection_ptr& db) override;
private:
	std::vector<std::string> m_point_types = { "None", "Default", "Bodkin", "Cutting", "Flaming" };
	sfg::Label::Ptr m_error_msg;
	sfg::Widget::Ptr m_page;
	sfg::ComboBox::Ptr m_point_selector;
	sfg::Entry::Ptr m_damage_entry;
	sfg::Entry::Ptr m_range_entry;
	db::prepared_statement_ptr m_insert_stmt = nullptr;
	db::prepared_statement_ptr m_max_id = nullptr;
};