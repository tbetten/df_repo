#include "stdafx.h"
#include "pages.h"
#include "builder.h"
#include <iostream>
#include <regex>

Builder* Page::m_builder{ nullptr };

// enums must be equal to item.h
enum class Damage_type { cr, cut, imp, pi_, pi, spec, ranged, Default };
enum class Point { None, Default, Bodkin, Cutting, Flaming };

Entity_page::Entity_page()
{
	auto outer_box = sfg::Box::Create(sfg::Box::Orientation::VERTICAL);
	auto name_box = sfg::Box::Create(sfg::Box::Orientation::HORIZONTAL);
	outer_box->Pack(name_box, false, true);

	name_box->Pack(sfg::Label::Create("entity name"));
	m_name_entry = sfg::Entry::Create();
	m_name_entry->SetRequisition(sf::Vector2f(120.0f, 0.0f));
	name_box->Pack(m_name_entry, false, true);

	m_buttons[Button::Shared] = sfg::CheckButton::Create("Shared data");
	m_buttons[Button::Shared]->GetSignal(sfg::CheckButton::OnToggle).Connect([this]() {handle_button(Button::Shared); });

	m_buttons[Button::Projectile] = sfg::CheckButton::Create("Projectile data");
	m_buttons[Button::Projectile]->GetSignal(sfg::CheckButton::OnToggle).Connect([this]() {handle_button(Button::Projectile); });

	outer_box->Pack(m_buttons[Button::Shared]);
	outer_box->Pack(m_buttons[Button::Projectile]);

	m_page = outer_box;
}

void Entity_page::handle_button(Button button)
{
	std::cout << "button toggled" << std::endl;
	bool status;
	m_buttons[button]->IsActive() ? status = true : status = false;
	Page_type type;
	switch (button)
	{
	case Entity_page::Button::Shared:
		type = Page_type::Shared;
		break;
	case Entity_page::Button::Projectile:
		type = Page_type::Projectile;
		break;
	default:
		break;
	}
	m_builder->set_tab_status(type, status);
}

bool Entity_page::validate()
{
	return m_name_entry->GetText().getSize();
}

std::string validate_text(Value_type type, sfg::Entry::Ptr entry)
{
	std::string text = entry->GetText();
	std::string result;
	switch (type)
	{
	case Value_type::String:
		result = "";
		break;
	case Value_type::Integer:
		std::regex_match(text, std::regex("[0-9]+")) ? result = "" : result = "Must be a valid integer value";
		break;
	case Value_type::Float:
		std::regex_match(text, std::regex("[0-9]+([.][0-9]+)?")) ? result = "" : result = "Must be a valid floating point number";
		break;
	default:
		break;
	}
	return result;
}


Shared_page::Shared_page()
{
	m_error_msg = sfg::Label::Create("");
	auto box = sfg::Box::Create(sfg::Box::Orientation::VERTICAL);
	box->Pack(m_error_msg);
	auto table = sfg::Table::Create();
	table->SetRowSpacings(10.0f);
	table->Attach(sfg::Label::Create("Name"), sf::Rect<sf::Uint32>(0, 0, 1, 1));
	table->Attach(sfg::Label::Create("Description"), sf::Rect<sf::Uint32>(0, 1, 1, 1));
	table->Attach(sfg::Label::Create("Price"), sf::Rect<sf::Uint32>(0, 2, 1, 1));
	table->Attach(sfg::Label::Create("Weight"), sf::Rect<sf::Uint32>(0, 3, 1, 1));

	m_name_entry = sfg::Entry::Create();
	m_description_entry = sfg::Entry::Create();
	m_price_entry = sfg::Entry::Create();
	m_weight_entry = sfg::Entry::Create();
	
	m_name_entry->GetSignal(sfg::Entry::OnTextChanged).Connect([this, &e = m_name_entry]() {m_error_msg->SetText( validate_text(Value_type::String, e)); });
	m_name_entry->SetRequisition(sf::Vector2f(120.0f, 0.0f));
	m_description_entry->GetSignal(sfg::Entry::OnTextChanged).Connect([this, &e = m_description_entry]() {m_error_msg->SetText( validate_text(Value_type::String, e)); });
	m_description_entry->SetRequisition(sf::Vector2f(120.0f, 0.0f));
	m_price_entry->GetSignal(sfg::Entry::OnTextChanged).Connect([this, &e = m_price_entry]() {m_error_msg->SetText( validate_text(Value_type::Integer, e)); });
	m_price_entry->SetRequisition(sf::Vector2f(120.0f, 0.0f));
	m_weight_entry->GetSignal(sfg::Entry::OnTextChanged).Connect([this, &e = m_weight_entry]() {m_error_msg->SetText( validate_text(Value_type::Float, e)); });
	m_weight_entry->SetRequisition(sf::Vector2f(120.0f, 0.0f));

	table->Attach(m_name_entry, sf::Rect<sf::Uint32>(1, 0, 1, 1));
	table->Attach(m_description_entry, sf::Rect<sf::Uint32>(1, 1, 1, 1));
	table->Attach(m_price_entry, sf::Rect<sf::Uint32>(1, 2, 1, 1));
	table->Attach(m_weight_entry, sf::Rect<sf::Uint32>(1, 3, 1, 1));

	box->Pack(table, false, true);
	m_page = box;
}


bool Shared_page::validate()
{
	if (m_name_entry->GetText().getSize() == 0) return false;
	if (m_description_entry->GetText().getSize() == 0) return false;
	if (m_price_entry->GetText().getSize() == 0 || validate_text(Value_type::Integer, m_price_entry) != "") return false;
	if (m_weight_entry->GetText().getSize() == 0 || validate_text(Value_type::Float, m_weight_entry) != "") return false;
	return true;
}

int Shared_page::insert_into_database(db::db_connection_ptr& db)
{
	std::string sql_string = "insert into item_shared (name, description, price, weight) values (?, ?, ?, ?)";
	std::string sql_max_index = "select max(id) as max_id from item_shared";
	if (m_insert_stmt == nullptr)
	{
		m_insert_stmt = db->prepare(sql_string);
	}
	if (m_max_index == nullptr)
	{
		try 
		{
			m_max_index = db->prepare(sql_max_index);
		}
		catch (std::string& msg)
		{
			std::cout << msg << std::endl;
		}
	}
	m_insert_stmt->bind(1, m_name_entry->GetText().toAnsiString());
	m_insert_stmt->bind(2, m_description_entry->GetText().toAnsiString());
	auto x =  atoi (m_price_entry->GetText().toAnsiString().c_str());
	m_insert_stmt->bind(3, x);
	auto y = atof(m_weight_entry->GetText().toAnsiString().c_str());
	m_insert_stmt->bind(4, y);
	int rc = m_insert_stmt->execute_row();
	std::cout << "result of insert is " << rc << std::endl;
	if (rc == SQLITE_DONE)  // success
	{
		m_insert_stmt->reset();
		rc = m_max_index->execute_row();
		if (rc == SQLITE_ROW)  // success
		{
			auto data = m_max_index->fetch_row();
			m_max_index->reset();
			return data["max_id"].integer_value;
		}
	}
	return 0;
}


Projectile_page::Projectile_page()
{
	auto box = sfg::Box::Create(sfg::Box::Orientation::VERTICAL);
	m_error_msg = sfg::Label::Create("");
	box->Pack(m_error_msg);
	auto table = sfg::Table::Create();
	table->SetRowSpacings(10.0f);

	auto point_label = sfg::Label::Create("Point type");
	auto damage_label = sfg::Label::Create("Damage bonus");
	auto range_label = sfg::Label::Create("Range bonus");

	m_point_selector = sfg::ComboBox::Create();
	std::for_each(m_point_types.begin(), m_point_types.end(), [&p = m_point_selector](auto& label) { p->AppendItem(label); });
	m_point_selector->SelectItem(1);
	m_damage_entry = sfg::Entry::Create();
	m_damage_entry->SetRequisition(sf::Vector2f(120.0f, 0.0f));
	m_damage_entry->GetSignal(sfg::Entry::OnTextChanged).Connect([this]() {m_error_msg->SetText(validate_text(Value_type::Integer, m_damage_entry)); });
	m_damage_entry->SetText("0");
	m_range_entry = sfg::Entry::Create();
	m_range_entry->SetRequisition(sf::Vector2f(120.0f, 0.0f));
	m_range_entry->GetSignal(sfg::Entry::OnTextChanged).Connect([this]() {m_error_msg->SetText(validate_text(Value_type::Integer, m_range_entry)); });
	m_range_entry->SetText("0");

	table->Attach(point_label, sf::Rect<sf::Uint32>(0, 0, 1, 1));
	table->Attach(damage_label, sf::Rect<sf::Uint32>(0, 1, 1, 1));
	table->Attach(range_label, sf::Rect<sf::Uint32> (0, 2, 1, 1));

	table->Attach(m_point_selector, sf::Rect<sf::Uint32>(1, 0, 1, 1));
	table->Attach(m_damage_entry, sf::Rect<sf::Uint32>(1, 1, 1, 1));
	table->Attach(m_range_entry, sf::Rect<sf::Uint32>(1, 2, 1, 1));

	box->Pack(table, false, true);
	m_page = box;
}

bool Projectile_page::validate()
{
	if (m_damage_entry->GetText().getSize() == 0 || validate_text(Value_type::Integer, m_damage_entry) != "") return false;
	if (m_range_entry->GetText().getSize() == 0 || validate_text(Value_type::Integer, m_range_entry) != "") return false;
	return true;
}

int Projectile_page::insert_into_database(db::db_connection_ptr& db)
{
	std::string sql_insert = "insert into projectile (point_type, damage_bonus, range_multiplier, damage_type, armour_divisor) values (?, ?, ?, ?, ?)";
	std::string sql_max_id = "select max(id) as max_id from projectile";
	if (m_insert_stmt == nullptr)
	{
		m_insert_stmt = db->prepare(sql_insert);
	}
	if (m_max_id == nullptr)
	{
		m_max_id = db->prepare(sql_max_id);
	}
	auto point = m_point_selector->GetSelectedItem();
	Damage_type damage_type;
	float armour_divisor = 1.0f;
	switch (static_cast <Point> (point))
	{
	case Point::None:   // sling bullet, use damage type from weapon 
		damage_type = Damage_type::Default;
		break;
	case Point::Default:  // standard broadhead point
		damage_type = Damage_type::imp;
		break;
	case Point::Bodkin:
		damage_type = Damage_type::pi;
		armour_divisor = 2.0f;
		break;
	case Point::Cutting:
		damage_type = Damage_type::cut;
		break;
	case Point::Flaming:
		damage_type = Damage_type::imp;
		break;
	}
	m_insert_stmt->bind(1, point);
	m_insert_stmt->bind(2, atoi(m_damage_entry->GetText().toAnsiString().c_str()));
	m_insert_stmt->bind(3, atoi(m_range_entry->GetText().toAnsiString().c_str()));
	m_insert_stmt->bind(4, static_cast<int>(damage_type));
	m_insert_stmt->bind(5, armour_divisor);
	int rc = m_insert_stmt->execute_row();
	if (rc == SQLITE_DONE)
	{
		m_insert_stmt->reset();
		int rc = m_max_id->execute_row();
		if (rc == SQLITE_ROW)
		{
			auto data = m_max_id->fetch_row();
			m_max_id->reset();
			return data["max_id"].integer_value;
		}
	}
	return 0;
}